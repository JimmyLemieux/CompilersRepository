package absyn;

abstract public class Exp extends Absyn {
}
