package absyn;

abstract public class Declaration extends Absyn {
    
}